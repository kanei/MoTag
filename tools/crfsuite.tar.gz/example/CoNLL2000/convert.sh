echo "Filtering columns"
cat ./$1 | awk -f 'setcol.awk' > $1.filtered
echo "Converting to UTF-8"
iconv --from-code=ISO-8859-2 --to-code=UTF-8 $1.filtered > $1.recoded
echo "Preparing data"
cat $1.recoded | ./to_crfsuite.py > $1.crfsuite
